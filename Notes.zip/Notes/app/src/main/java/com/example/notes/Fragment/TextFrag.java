package com.example.notes.Fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.notes.Adapter.TextNoteAdapter;
import com.example.notes.R;

public class TextFrag extends Fragment {
    RecyclerView recyclerView;
    FloatingActionButton fab;
    TextNoteAdapter adapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.note_text , container , false);
        recyclerView = v.findViewById(R.id.recyclerview_textnote);
        fab = v.findViewById(R.id.fab_text_note);
        adapter = new TextNoteAdapter();
        recyclerView.setAdapter(adapter);

        return v;
    }
}
