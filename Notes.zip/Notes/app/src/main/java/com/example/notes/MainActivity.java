package com.example.notes;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import com.example.notes.Adapter.TabAdapter;
import com.example.notes.Fragment.MainFrag;
import com.example.notes.Fragment.TextFrag;
import com.example.notes.Fragment.VoiceFrag;

public class MainActivity extends AppCompatActivity {
    FragmentTransaction fragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    protected void onStart() {
        super.onStart();
        FragmentManager manager = getSupportFragmentManager();
       fragmentTransaction = manager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, new MainFrag());
        fragmentTransaction.commit();

    }
}